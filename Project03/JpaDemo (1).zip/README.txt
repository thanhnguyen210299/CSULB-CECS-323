Extract the "jpademo" folder to your computer.
Then open THE FOLDER ITSELF in VS Code or IntelliJ IDEA.

Don't open just one .java file.

Don't open the src folder.

Open "jpademo" itself.