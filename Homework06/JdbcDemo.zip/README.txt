You should be able to open *this entire folder* in either Visual Studio Code (using Open Folder) or IntelliJ IDEA (using Open Project).

In VS Code you will need to install "Extension Pack for Java" from the Extensions window. (Left side, the icon with four small squares.)