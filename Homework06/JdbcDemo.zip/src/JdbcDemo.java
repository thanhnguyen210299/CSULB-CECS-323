import application.Customer;
import application.Employee;
import db.DbCustomer;
import db.DbEmployee;

import java.sql.*;
import java.util.List;
import java.util.Scanner;

/**
 * This program demonstrates how to connect to an Apache Derby database.
 */
public class JdbcDemo {
	public static void main(String[] args) {
		try {
			/*
			 First, we define a "connection string", which indicates what type of database we want to connect to,
			 and where to find it.
			*/
            String dbURL = "jdbc:derby:D:/CSULB/2021 Fall/CECS 323/DataSources/FirstTry";
			/*
			 This database is a Derby database at the specified absolute directory; it will not work if your
			 database is somewhere else.
			 Second, we open a Connection with that connection string. This could fail with exceptions for any number
			 of reasons: a bad connection string, a refused connection, an out-of-date driver, blah blah blah...
			*/

            Connection conn = DriverManager.getConnection(dbURL);
			if (conn != null) {
				System.out.println("Connected to database!");
			}

			/*
			 We can now construct a Statement, which represents one request to the database.
			 We must define this variable outside the try, so we can close it later in the finally.
			*/
            Statement stmt = null;
			try {
				// Here is our query: give me all the customers!
				String query = "select * from CECS323LAB.CUSTOMERS";

				// The Connection creates a Statement object tied to that Connection.
				stmt = conn.createStatement();
				// A Statement can execute individual query given its SQL string.
				ResultSet data = stmt.executeQuery(query);

				/*
				 executeQuery returns a ResultSet: an Iterator-like object that "walks" through the rows returned
				 by the query. Each column is converted to an appropriate Java type, like String, Date, int, etc.
				 rs.next() moves to the next result, and returns False if there was not another result to move to.
				*/

                while (data.next()) {
					/*
					 The various get*() methods return the value at a given column name for the *current row*,
					 converted to the specified type.
					*/
                    String name = data.getString("CUSTOMERNAME");
					int customerNumber = data.getInt("CUSTOMERNUMBER");
					System.out.println(customerNumber + ": " + name);
				}
			}
			catch (SQLException e) {
				throw new Error("Problem", e);
			}
			finally {
                /*
                 Statements need to be closed after we are done with them. This is often overlooked and can lead
                 to serious performance problems, including the inability to run more statements.
                 Putting this in the finally block means the statement will always be closed, even if we encounter
                 an exception.
                */
                if (stmt != null) {
					stmt.close();
				}
			}

			/*
			 Example #2: the INCORRECT way to do a parameterized query, vulnerable to SQL injection attacks.
			*/
			System.out.println();
			System.out.println("DEMO #2");
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter a Customer name:");
			String customerName = scan.nextLine();

			try {
				stmt = conn.createStatement();
				// Build the query string using the user's input for the WHERE clause.
				String query = "select * from CECS323LAB.CUSTOMERS where CUSTOMERNAME = '" + customerName + "'";
				ResultSet data = stmt.executeQuery(query);

				// Check to see if there is a result.
				if (data.next()) {
					System.out.println("Your customer number: " + data.getInt("CUSTOMERNUMBER"));
				}
				else {
					System.out.println("No customer with name " + customerName);
				}

			}
			catch (SQLException e) {
				throw new Error("Problem", e);
			}
			finally {
				if (stmt != null) {
					stmt.close();
				}
			}
			/*
			The CORRECT way to include user input as part of a query is to *parameterize* the query. JDBC's 
			PreparedStatement class allows ? as a placeholder for parameterized values that can be added to the query.
			JDBC handles sanitizing the inputs for you.
			*/
			System.out.println();
			System.out.println("Customer name lookup with PreparedStatement:");
			PreparedStatement prep = null;
			try {

				String query = "select * from CECS323LAB.CUSTOMERS where CUSTOMERNAME = ?";
				prep = conn.prepareStatement(query);
				prep.setString(1, customerName); // replace the first ? with the sanitized customer's name.
				
				ResultSet data = prep.executeQuery();
				// Check to see if there is a result.
				if (data.next()) {
					System.out.println("Your customer number: " + data.getInt("CUSTOMERNUMBER"));
				}
				else {
					System.out.println("No customer with name " + customerName);
				}

			}
			catch (SQLException e) {
				throw new Error("Problem", e);
			}
			finally {
				if (stmt != null) {
					stmt.close();
				}
			}


			System.out.println();
			System.out.println("DEMO #3");
			/*
			Demo #2: using a "3-tier architecture" with a module to create Java application.Customer objects
			from rows returned by a Connection.
			 */
			List<Customer> allCustomers = DbCustomer.getAllCustomers(conn);
			for (Customer c : allCustomers) {
				Employee e = DbEmployee.getEmployee(conn, c.getSalesRepEmployeeNumber());
				if (e != null) {
					System.out.println(c.getCustomerNumber() + ": " + c.getCustomerName() + "; REP " +
							e.getFirstName() + " " + e.getLastName());
				}
				else {
					System.out.println(c.getCustomerNumber() + ": " + c.getCustomerName());
				}
			}

			/*
			The 3-tier architecture is a definite improvement, but it doesn't address all the problems with JDBC.
			Now we have classes instead of primitives and DataSets, but changes to the database now need to also change
			the corresponding Application class. This is prone to error!

			It's also a lot of code to write... code that no one really *enjoys* writing.
			 */

		}
		catch (SQLException ex) {
			ex.printStackTrace();
		}
	}
}